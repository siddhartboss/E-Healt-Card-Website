<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
	<link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body>
<div class="container">
	<div class="header">

	<h2 >Sign Up</h2>

    </div>

    <form action="signupconnect.php" method="POST" enctype="multipart/form-data" >
		<div>
			<label for="fname">First Name : </label>
			<input type="text" name="fname" required>
		</div>

		<div>
			<label for="mname">Middle Name : </label>
			<input type="text" name="mname" required>
		</div>

		<div>
			<label for="lname">Last Name : </label>
			<input type="text" name="lname" required>
		</div>

		<div>
			<label for="email">Email : </label>
			<input type="email" name="email" required>
		</div>

		<div>
			<label for="password">Password : </label>
			<input type="password" name="password" required>
		</div>

		<div>
			<label for="password1">Confirm Password : </label>
			<input type="password" name="password1" required>
		</div>

		<div>
			<label for="contact">Contact number : </label>
			<input type="tel" pattern="[0-9]{10}" name="contact" required>
		</div>

		<div>
			<label for="gender">Gender : </label><br>
			<input type="radio" id="male" name="gender" value="male">
  			<label for="male">Male</label><br>
 			<input type="radio" id="female" name="gender" value="female">
  			<label for="female">Female</label><br>
  			<input type="radio" id="other" name="gender" value="other">
  			<label for="other">Other</label>
		</div>

		<div>
			<label for="dob">Date of birth : </label>
  			<input type="date" name="dob">
		</div>

		<div>
			<label for="age">Age : </label>
			<input type="number" name="age" required>
		</div>

		<div>
			<label for="address">Address : </label>
			<textarea name="address" rows="5" cols="30"></textarea>
		</div>

		<div>
			<label for="profileImage">Profile Image : </label>
			<!--<input type="file" name="profileImage" required> -->
			<input type="file" name="uploadfile" value=""/>
		    <!-- <input type ="submit" name= "submit" value="Upload"/> --> 
		</div> 
        
        <div>
        	<button type="submit" name="register_user">Submit</button>
        </div>
		

    </form>

</div>
</body>
</html>