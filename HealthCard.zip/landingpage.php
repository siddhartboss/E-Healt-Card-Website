<html> 
<head>
	<title> Health Card </title>
	<link rel="stylesheet" type="text/css" href="landingpagestyle.css">
</head>
<body>
	<header>
		<div class="main">
			<div class="logo">
				<img src = >

			<ul>
				<li><a href="landingpage.php"> Home </a> </li>
				<li><a href="about.html"> About </a> </li>
                <li><a href="userguide.html"> User Guide </a> </li>
                <!--<li><a href="construction.php"> Contacts </a> </li>-->
            </ul>
        </div>
        <div class ="title">
        	<h1>Generate your Health Card</h1> 
        </div>
        <div class= "button">
        	<a href ="login.php" class="btn">Login</a>
            <a href ="signupnew.php" class="btn">Sign Up</a>
        </header>
    </body>
    </html>