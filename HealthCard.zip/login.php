<!DOCTYPE html>
<html>
<head>
     <title>Login</title>
     <link rel="stylesheet" type="text/css" href="signup.css">
</head>
<body>

  <div class = "container">
    <div class= "header">
      <h2 style='font-family: "Roboto", sans-serif;'>Login</h2>
    </div>

    <form action="loginprocess.php" method="POST" style='font-family: "Roboto", sans-serif;'>

      <div>
        <label for="email"> User Id: </label>
        <input type="text" name="email" required>
      </div>
      <div>
        <label for="password"> Password: </label>
        <input type="password" name="password" required>
      </div>

      <button type="submit" name="login_btn"> Submit </button>

    </form>

  </div>
</body>
</html>
