<!DOCTYPE html>
<html>
<head>
	<link rel ="stylesheet" href="signupstyle.css">
	<title>User Registration</title>
</head>
<body>
<div class="container">
	

	<h1 class = "heading" > Sign Up</h1>
<hr>
    

    <form action="signupconnect.php" method="POST" enctype="multipart/form-data">
    	<h2> User Information </h2>
		<p>
			<label for="fname">First Name : </label>
			<input type="text" name="fname" required>
		</p>
		<p>
			<label for="mname">Middle Name : </label>
			<input type="text" name="mname" required>
		</p>

		<p>
			<label for="lname">Last Name : </label>
			<input type="text" name="lname" required>
		</p>

		<p>
			<label for="email">Email : </label>
			<input type="email" name="email" required>
		</p>

		<p>
			<label for="password">Password : </label>
			<input type="password" name="password" required>
		</p>

		<p>
			<label for="password1">Confirm Password : </label>
			<input type="password" name="password1" required>
		</p>

		<p>
			<label for="contact">Contact number : </label>
			<input type="tel" pattern="[0-9]{10}" name="contact" required>
		</p>

		<p>
			<fieldset>
			<label for="gender">Gender : </label><br>
			<input type="radio" id="male" name="gender" value="male">
  			<label for="male">Male</label> 
 			<input type="radio" id="female" name="gender" value="female">
  			<label for="female">Female</label>
  			<input type="radio" id="other" name="gender" value="other">
  			<label for="other">Other</label></fieldset>
		</p>

		<p>
			<label for="dob">Date of birth : </label>
  			<input type="date" name="dob">
		</p>

		<p>
			<label for="age">Age : </label>
			<input type="number" name="age" required>
		</p> 

		<p>
			<label for="address">Address : </label><br>
			<textarea name="address" rows="5" cols="30"></textarea>
		</p>

		<p>
			<!--
			<label for="profileImage">Profile Image : </label>
			<input type="file" name="uploadfile" required value=""/> -->
			<label for="profileImage">Profile Image : </label>
			<!--<input type="file" name="profileImage" required> -->
			<input type="file" name="uploadfile" value=""/>
		    <!-- <input type ="submit" name= "submit" value="Upload"/> -->
		</p> 
        
        <p class="wrapper">
        	<button type="submit" name="register_user">Submit</button>
        </p>
		

    </form>

</div>








</body>
</html>