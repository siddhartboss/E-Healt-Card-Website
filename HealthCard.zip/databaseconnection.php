<?php
/*$con = mysqli_connect ("localhost","root","root","user information");

//check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MYSQL:" . mysqli_connect_error();
}
else
{
  echo "success";
}*/

$con = new mysqli('localhost','root','','user information');
if($con -> connect_error)
    {
    	die('Connection Error : '.$conn->connect_error);
    }    


?>