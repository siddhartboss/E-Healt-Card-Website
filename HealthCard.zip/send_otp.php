<?php
session_start();
$con=mysqli_connect('localhost','root','','user information');
$email=$_POST['email'];
$res=mysqli_query($con,"SELECT * from signupinfo where email='$email'");
$count=mysqli_num_rows($res);
if($count>0){
	//Checking if email already verified
	$row = $res->fetch_assoc();
	if($row['email_verified'] == "NO")
	{
		mysqli_query($con,"INSERT INTO user_otp (`email`, `otp`) VALUES ('$email', '')");
		$otp=rand(11111,99999);
		mysqli_query($con,"UPDATE user_otp set otp='$otp' where email='$email'");
		$html="Your otp verification code is ".$otp;
		$_SESSION['EMAIL']=$email;
		smtp_mailer($email,'OTP Verification',$html);
		echo "yes";
    }
    else
    {
    	echo "already_verified";
    }
}else{
	echo "not_exist";
}

function smtp_mailer($to,$subject, $msg){
	require_once("smtp/class.phpmailer.php");
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPDebug = 1; 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'TLS'; 
	$mail->Host = "smtp.sendgrid.net";
	//$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; //587  //535 //465
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = "apikey";
	$mail->Password = "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";
	$mail->SetFrom("jahnavi.mul@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	if(!$mail->Send()){
		return 0;
	}else{
		return 1;
	}
}
?>