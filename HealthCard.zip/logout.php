<?php
session_start();
unset($_SESSION['email']);
unset($_SESSION['password']);
//header("Location : landingpage.php");
echo "Logged out Successfully.";
echo '<br><a href="landingpage.php">MAIN PAGE</a>';
?>