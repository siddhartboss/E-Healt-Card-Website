<!-- PRINTABLE HEALTH CARD-->

<?php 

//include ('loginprocess.php');
session_start();
$con = new mysqli('localhost','root','','user information');
if($con -> connect_error)
    {
      die('Connection Error : '.$con->connect_error);
    }

$sql= "SELECT * FROM signupinfo WHERE email = '".$_SESSION['email']."' ";
$result = $con->query($sql); 
$row = $result->fetch_assoc(); 

 if($row['healthID'] == NULL) 
		{
   			 if($row['verified'] == "YES" AND $row['email_verified'] == "YES") //ADDED HERE
			{
				$var = $row['id'];
                $hid = 10000 + $var;
				$row['healthID'] =  10000 + $var;
                $sql = "UPDATE signupinfo SET healthID = $hid
                 WHERE email = '".$_SESSION['email']."' AND password = '".$_SESSION['password']."'";
                $result1 = $con->query($sql);
			}
		}


 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Final Card</title>
    <link rel="stylesheet" type="text/css" href="FinalCard.css">
</head>
<body>
	<div>
		<?php if($row['healthID'] == NULL) 
		{
			echo '<h2>HEALTH ID WILL BE GENERATED ONLY WHEN ALL THE DETAILS HAVE BEEN ENTERED AND VERIFIED</h2>';
		}?>
<br>
	</div>

    <div class="cardbox">

	<div class="generalInfo">
        <ul>
		<li><div class="image">
			<?php  
                            
                $image = $row['profileImage'];
                $image_src = "Images/".$image;
                                
            ?>
            <img src='<?php echo $image_src;  ?>' height="100px" width="100px">

		</div></li>		
		<li><div class="info">
			<p>NAME: <?php 

                echo $row['fname']." ".$row['mname']." ".$row['lname'];
            ?></p>

            <p>DOB: <?php 

                echo $row['dob'];
            ?></p>
            <p>AGE: <?php 

                echo $row['age'];
            ?></p>
            <p>GENDER: <?php 

                echo $row['gender'];
            ?></p>
            <p>ADDRESS: <?php 

                echo $row['address'];
            ?></p>
            <p>CONTACT NUMBER: 
            <?php 

                echo $row['contact'];
            ?></p>
		</div></li>
    </ul>
	</div>


	<div class="healthID">
		<p>HEALTH ID:
			<?php if($row['healthID'] !== NULL) 
		    {
				echo $row['healthID'];
			}?>
		</p>

	</div>

<br>
	<div class="healthInfo">
        <ul>
		<li><p>BLOOD GROUP: <?php 

                echo $row['bloodGroup'];
            ?></p>
        <li><p>WEIGHT: <?php 

                echo $row['weight']." kg";
            ?></p>
        <li><p>HEIGHT: <?php 

                echo $row['height']." cms";
            ?></p>        
		</ul><br><br>

        <p>ILLNESS: <?php 

                echo $row['illness'];
            ?></p><br>

        <p>Emergency Contact: <?php 

                echo $row['emergencyContact'];
            ?></p>    

	</div>
</div>

</body>
</html>